<?php
$conn = new mysqli("localhost", "root", "root", "supercar");

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

$sql = "SELECT * FROM contact ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Gestion des Messages</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #1e1e2e; color: white; }
        .sidebar { height: 100vh; background-color: #242424; padding: 15px; }
        .sidebar a { color: white; text-decoration: none; display: block; padding: 10px; }
        .sidebar a:hover { background-color: #444; }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-3 col-lg-2 d-md-block sidebar">
            <h2 class="text-center">Admin</h2>
            <a href="accueil.html">📊 Tableau de bord</a>
            <a href="voiture.php">🚗 Gestion des voitures</a>
            <a href="service.php">🛠 Gestion des services</a>
            <a href="essais.html">📋 Demandes d’essai</a>
            <a href="contact.php">📩 Messages</a>
            <a href="#logout">🔒 Déconnexion</a>
        </nav>

        <!-- Main content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <h1 class="mt-4">📩 Messages reçus</h1>

            <table class="table table-dark table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Email</th>
                        <th>Objet</th>
                        <th>Message</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <?php 
                        $statut = isset($row['statut']) ? $row['statut'] : 'non lu'; 
                        $badge = $statut == 'lu' ? 'bg-success' : 'bg-warning'; 
                        ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= htmlspecialchars($row['nom']) ?></td>
                            <td><?= htmlspecialchars($row['email']) ?></td>
                            <td><?= htmlspecialchars($row['objet']) ?></td>
                            <td><?= nl2br(htmlspecialchars($row['message'])) ?></td>
                            <td><span class="badge <?= $badge ?>"><?= $statut ?></span></td>
                            <td>
                                <form method="POST" action="traiter_contact.php" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                    <input type="hidden" name="action" value="lu">
                                    <button class="btn btn-success btn-sm" <?= $statut == 'lu' ? 'disabled' : '' ?>>Lu</button>
                                </form>

                                <form method="POST" action="traiter_contact.php" style="display:inline;" onsubmit="return confirm('Supprimer ce message ?');">
                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                    <input type="hidden" name="action" value="supprimer">
                                    <button class="btn btn-danger btn-sm">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>
