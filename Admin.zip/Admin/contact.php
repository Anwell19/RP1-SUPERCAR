<?php
$conn = new mysqli("mysql-anwellmcci.alwaysdata.net", "434572", "espace2311!", "anwellmcci_supercar");

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

$sql = "SELECT * FROM contact ORDER BY id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Gestion des Messages</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a0a;
            color: #fff;
            overflow-x: hidden;
        }

        /* Container principal */
        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #1a1a1a 0%, #0a0a0a 100%);
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 30px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-logo {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 30px;
            color: #aaa;
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
            font-weight: 600;
        }

        .menu-item::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(135deg, #e60000, #ff4444);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .menu-item:hover,
        .menu-item.active {
            color: #fff;
            background: rgba(230, 0, 0, 0.1);
        }

        .menu-item:hover::before,
        .menu-item.active::before {
            opacity: 1;
        }

        .logout-btn {
            margin: 20px 30px;
            padding: 15px;
            background: rgba(230, 0, 0, 0.1);
            border: 2px solid rgba(230, 0, 0, 0.3);
            border-radius: 12px;
            color: #e60000;
            text-align: center;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-weight: 700;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: rgba(230, 0, 0, 0.2);
            transform: translateY(-2px);
        }

        /* Main content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 40px;
        }

        /* Header */
        .content-header {
            margin-bottom: 40px;
        }

        .content-header h1 {
            font-size: 42px;
            font-weight: 900;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .content-subtitle {
            color: #666;
            font-size: 16px;
        }

        /* Stats rapides */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            border-color: rgba(230, 0, 0, 0.5);
        }

        .stat-number {
            font-size: 36px;
            font-weight: 900;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }

        .stat-label {
            color: #666;
            font-size: 14px;
            font-weight: 600;
        }

        /* Grille des messages */
        .messages-grid {
            display: grid;
            gap: 25px;
        }

        /* Carte de message */
        .message-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 25px;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        .message-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(135deg, #ffc107, #ffeb3b);
        }

        .message-card.read::before {
            background: linear-gradient(135deg, #4caf50, #8bc34a);
        }

        .message-card:hover {
            transform: translateX(10px);
            border-color: rgba(230, 0, 0, 0.5);
            box-shadow: 0 10px 40px rgba(230, 0, 0, 0.2);
        }

        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .message-sender {
            flex: 1;
        }

        .sender-name {
            font-size: 20px;
            font-weight: 800;
            color: #fff;
            margin-bottom: 5px;
        }

        .sender-email {
            color: #666;
            font-size: 14px;
        }

        .message-meta {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .message-id {
            font-size: 12px;
            color: #666;
            font-weight: 600;
        }

        .status-badge {
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .badge-unread {
            background: rgba(255, 193, 7, 0.2);
            color: #ffc107;
            border: 1px solid rgba(255, 193, 7, 0.3);
        }

        .badge-read {
            background: rgba(76, 175, 80, 0.2);
            color: #4caf50;
            border: 1px solid rgba(76, 175, 80, 0.3);
        }

        .message-subject {
            background: rgba(230, 0, 0, 0.1);
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 15px;
            border-left: 3px solid #e60000;
        }

        .subject-label {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }

        .subject-text {
            font-size: 16px;
            font-weight: 700;
            color: #e60000;
        }

        .message-body {
            color: #ccc;
            line-height: 1.8;
            margin-bottom: 20px;
            padding: 15px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 12px;
        }

        .message-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 14px;
            text-align: center;
        }

        .btn-read {
            background: rgba(76, 175, 80, 0.2);
            color: #4caf50;
            border: 1px solid rgba(76, 175, 80, 0.3);
        }

        .btn-read:hover:not(:disabled) {
            background: #4caf50;
            color: #fff;
            transform: translateY(-2px);
        }

        .btn-read:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .btn-delete {
            background: rgba(244, 67, 54, 0.2);
            color: #f44336;
            border: 1px solid rgba(244, 67, 54, 0.3);
        }

        .btn-delete:hover {
            background: #f44336;
            color: #fff;
            transform: translateY(-2px);
        }

        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: #666;
        }

        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state h3 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #aaa;
        }

        /* Responsive */
        @media (max-width: 968px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .main-content {
                margin-left: 0;
            }

            .message-header {
                flex-direction: column;
            }

            .message-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-logo">SuperCars</h2>
            </div>
            
            <div class="sidebar-menu">
                <a href="dashboard.html" class="menu-item">
                    <span>📊</span>
                    <span>Tableau de bord</span>
                </a>
                <a href="voiture.php" class="menu-item">
                    <span>🚗</span>
                    <span>Gestion des voitures</span>
                </a>
                <a href="service.php" class="menu-item">
                    <span>🛠</span>
                    <span>Gestion des services</span>
                </a>
                <a href="essais.php" class="menu-item">
                    <span>📋</span>
                    <span>Demandes d'essai</span>
                </a>
                <a href="contact.php" class="menu-item active">
                    <span>📩</span>
                    <span>Messages</span>
                </a>
            </div>

            <a href="deconnexion.php" class="logout-btn">
                <span>🔓</span>
                <span>Déconnexion</span>
            </a>
        </nav>
        
        <!-- Main content -->
        <main class="main-content">
            <div class="content-header">
                <h1>Messages reçus</h1>
                <p class="content-subtitle">Gérez les messages de contact</p>
            </div>

            <!-- Stats -->
            <div class="stats-grid">
                <?php
                $messages = [];
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $messages[] = $row;
                    }
                    $result->data_seek(0);
                }
                $total = count($messages);
                $non_lus = count(array_filter($messages, fn($m) => ($m['statut'] ?? 'non lu') === 'non lu'));
                $lus = $total - $non_lus;
                ?>
                <div class="stat-card">
                    <div class="stat-number"><?= $total ?></div>
                    <div class="stat-label">Total messages</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= $non_lus ?></div>
                    <div class="stat-label">Non lus</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= $lus ?></div>
                    <div class="stat-label">Lus</div>
                </div>
            </div>

            <!-- Grille des messages -->
            <?php if ($result->num_rows > 0): ?>
            <div class="messages-grid">
                <?php while ($row = $result->fetch_assoc()): 
                    $statut = isset($row['statut']) ? $row['statut'] : 'non lu';
                    $isRead = $statut === 'lu';
                ?>
                <div class="message-card <?= $isRead ? 'read' : '' ?>">
                    <div class="message-header">
                        <div class="message-sender">
                            <div class="sender-name"><?= htmlspecialchars($row['nom']) ?></div>
                            <div class="sender-email">✉️ <?= htmlspecialchars($row['email']) ?></div>
                        </div>
                        <div class="message-meta">
                            <span class="message-id">#<?= $row['id'] ?></span>
                            <span class="status-badge <?= $isRead ? 'badge-read' : 'badge-unread' ?>">
                                <?= $isRead ? 'Lu' : 'Non lu' ?>
                            </span>
                        </div>
                    </div>

                    <div class="message-subject">
                        <div class="subject-label">Objet</div>
                        <div class="subject-text"><?= htmlspecialchars($row['objet']) ?></div>
                    </div>

                    <div class="message-body">
                        <?= nl2br(htmlspecialchars($row['message'])) ?>
                    </div>

                    <div class="message-actions">
                        <form method="POST" action="traiter_contact.php" style="display:inline; flex: 1;">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <input type="hidden" name="action" value="lu">
                            <button class="btn btn-read" <?= $isRead ? 'disabled' : '' ?> style="width: 100%;">
                                ✓ Marquer comme lu
                            </button>
                        </form>

                        <form method="POST" action="traiter_contact.php" style="display:inline; flex: 1;" 
                              onsubmit="return confirm('Supprimer ce message ?');">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <input type="hidden" name="action" value="supprimer">
                            <button class="btn btn-delete" style="width: 100%;">
                                🗑️ Supprimer
                            </button>
                        </form>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <div class="empty-state-icon">📩</div>
                <h3>Aucun message</h3>
                <p>Les nouveaux messages apparaîtront ici</p>
            </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
<?php $conn->close(); ?>