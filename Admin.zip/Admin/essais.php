<?php
// Connexion à la base de données
require_once 'bdconnect.php';

// Vérifie la connexion
if (!$bdd) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

// Récupération des demandes
$sql = "SELECT * FROM essai ORDER BY id DESC";
$result = mysqli_query($bdd, $sql);

$demandes = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $demandes[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Gestion des Demandes d'Essai</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a0a;
            color: #fff;
            overflow-x: hidden;
        }

        /* Container principal */
        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #1a1a1a 0%, #0a0a0a 100%);
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 30px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-logo {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 30px;
            color: #aaa;
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
            font-weight: 600;
        }

        .menu-item::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(135deg, #e60000, #ff4444);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .menu-item:hover,
        .menu-item.active {
            color: #fff;
            background: rgba(230, 0, 0, 0.1);
        }

        .menu-item:hover::before,
        .menu-item.active::before {
            opacity: 1;
        }

        .logout-btn {
            margin: 20px 30px;
            padding: 15px;
            background: rgba(230, 0, 0, 0.1);
            border: 2px solid rgba(230, 0, 0, 0.3);
            border-radius: 12px;
            color: #e60000;
            text-align: center;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-weight: 700;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: rgba(230, 0, 0, 0.2);
            transform: translateY(-2px);
        }

        /* Main content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 40px;
        }

        /* Header */
        .content-header {
            margin-bottom: 40px;
        }

        .content-header h1 {
            font-size: 42px;
            font-weight: 900;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .content-subtitle {
            color: #666;
            font-size: 16px;
        }

        /* Stats rapides */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            border-color: rgba(230, 0, 0, 0.5);
        }

        .stat-number {
            font-size: 36px;
            font-weight: 900;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }

        .stat-label {
            color: #666;
            font-size: 14px;
            font-weight: 600;
        }

        /* Grille des demandes */
        .requests-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
            gap: 30px;
        }

        /* Carte de demande */
        .request-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 25px;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        .request-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #e60000, #ff4444);
        }

        .request-card.en-attente::before {
            background: linear-gradient(90deg, #ffc107, #ffeb3b);
        }

        .request-card.approuvee::before {
            background: linear-gradient(90deg, #4caf50, #8bc34a);
        }

        .request-card.refusee::before {
            background: linear-gradient(90deg, #f44336, #e91e63);
        }

        .request-card:hover {
            transform: translateY(-10px);
            border-color: rgba(230, 0, 0, 0.5);
            box-shadow: 0 20px 60px rgba(230, 0, 0, 0.3);
        }

        .request-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 20px;
        }

        .request-id {
            font-size: 12px;
            color: #666;
            font-weight: 600;
        }

        .status-badge {
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .badge-warning {
            background: rgba(255, 193, 7, 0.2);
            color: #ffc107;
            border: 1px solid rgba(255, 193, 7, 0.3);
        }

        .badge-success {
            background: rgba(76, 175, 80, 0.2);
            color: #4caf50;
            border: 1px solid rgba(76, 175, 80, 0.3);
        }

        .badge-danger {
            background: rgba(244, 67, 54, 0.2);
            color: #f44336;
            border: 1px solid rgba(244, 67, 54, 0.3);
        }

        .request-info {
            margin-bottom: 20px;
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .info-item:last-child {
            border-bottom: none;
        }

        .info-icon {
            font-size: 18px;
            width: 24px;
        }

        .info-label {
            color: #666;
            font-size: 13px;
            min-width: 80px;
        }

        .info-value {
            color: #fff;
            font-weight: 600;
            font-size: 14px;
        }

        .car-name {
            background: rgba(230, 0, 0, 0.1);
            color: #e60000;
            padding: 8px 12px;
            border-radius: 8px;
            font-weight: 700;
        }

        .request-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .btn {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 14px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        .btn-approve {
            background: rgba(76, 175, 80, 0.2);
            color: #4caf50;
            border: 1px solid rgba(76, 175, 80, 0.3);
        }

        .btn-approve:hover {
            background: #4caf50;
            color: #fff;
            transform: translateY(-2px);
        }

        .btn-reject {
            background: rgba(244, 67, 54, 0.2);
            color: #f44336;
            border: 1px solid rgba(244, 67, 54, 0.3);
        }

        .btn-reject:hover {
            background: #f44336;
            color: #fff;
            transform: translateY(-2px);
        }

        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: #666;
        }

        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state h3 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #aaa;
        }

        /* Responsive */
        @media (max-width: 968px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .main-content {
                margin-left: 0;
            }

            .requests-grid {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-logo">SuperCars</h2>
            </div>
            
            <div class="sidebar-menu">
                <a href="dashboard.html" class="menu-item">
                    <span>📊</span>
                    <span>Tableau de bord</span>
                </a>
                <a href="voiture.php" class="menu-item">
                    <span>🚗</span>
                    <span>Gestion des voitures</span>
                </a>
                <a href="service.php" class="menu-item">
                    <span>🛠</span>
                    <span>Gestion des services</span>
                </a>
                <a href="essais.php" class="menu-item active">
                    <span>📋</span>
                    <span>Demandes d'essai</span>
                </a>
                <a href="contact.php" class="menu-item">
                    <span>📩</span>
                    <span>Messages</span>
                </a>
            </div>

            <a href="deconnexion.php" class="logout-btn">
                <span>🔓</span>
                <span>Déconnexion</span>
            </a>
        </nav>
        
        <!-- Main content -->
        <main class="main-content">
            <div class="content-header">
                <h1>Demandes d'Essai</h1>
                <p class="content-subtitle">Gérez les demandes de test drive</p>
            </div>

            <!-- Stats -->
            <div class="stats-grid">
                <?php
                $total = count($demandes);
                $en_attente = count(array_filter($demandes, fn($d) => ($d['statut'] ?? 'En attente') === 'En attente'));
                $approuvees = count(array_filter($demandes, fn($d) => ($d['statut'] ?? '') === 'Approuvée'));
                $refusees = count(array_filter($demandes, fn($d) => ($d['statut'] ?? '') === 'Refusée'));
                ?>
                <div class="stat-card">
                    <div class="stat-number"><?= $total ?></div>
                    <div class="stat-label">Total</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= $en_attente ?></div>
                    <div class="stat-label">En attente</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= $approuvees ?></div>
                    <div class="stat-label">Approuvées</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= $refusees ?></div>
                    <div class="stat-label">Refusées</div>
                </div>
            </div>

            <!-- Grille des demandes -->
            <?php if (count($demandes) > 0): ?>
            <div class="requests-grid">
                <?php foreach ($demandes as $demande): 
                    $statut = $demande['statut'] ?? 'En attente';
                    $statusClass = '';
                    $badgeClass = 'badge-warning';
                    
                    if ($statut === 'Approuvée') {
                        $statusClass = 'approuvee';
                        $badgeClass = 'badge-success';
                    } elseif ($statut === 'Refusée') {
                        $statusClass = 'refusee';
                        $badgeClass = 'badge-danger';
                    } else {
                        $statusClass = 'en-attente';
                    }
                ?>
                <div class="request-card <?= $statusClass ?>">
                    <div class="request-header">
                        <span class="request-id">#<?= isset($demande['id']) ? htmlspecialchars($demande['id']) : 'N/A' ?></span>
                        <span class="status-badge <?= $badgeClass ?>"><?= htmlspecialchars($statut) ?></span>
                    </div>

                    <div class="request-info">
                        <div class="info-item">
                            <span class="info-icon">👤</span>
                            <span class="info-label">Client:</span>
                            <span class="info-value"><?= isset($demande['nom']) ? htmlspecialchars($demande['nom']) : 'N/A' ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-icon">✉️</span>
                            <span class="info-label">Email:</span>
                            <span class="info-value"><?= isset($demande['email']) ? htmlspecialchars($demande['email']) : 'N/A' ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-icon">📅</span>
                            <span class="info-label">Date:</span>
                            <span class="info-value"><?= isset($demande['date_essai']) ? htmlspecialchars($demande['date_essai']) : 'N/A' ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-icon">🚗</span>
                            <span class="info-label">Véhicule:</span>
                            <span class="car-name"><?= isset($demande['marque']) ? htmlspecialchars($demande['marque']) : 'N/A' ?></span>
                        </div>
                    </div>

                    <?php if ($statut === 'En attente'): ?>
                    <div class="request-actions">
                        <a href="approuver.php?id=<?= $demande['id'] ?>" class="btn btn-approve">
                            ✓ Approuver
                        </a>
                        <a href="refuser.php?id=<?= $demande['id'] ?>" class="btn btn-reject">
                            ✕ Refuser
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <div class="empty-state-icon">📋</div>
                <h3>Aucune demande d'essai</h3>
                <p>Les nouvelles demandes apparaîtront ici</p>
            </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>