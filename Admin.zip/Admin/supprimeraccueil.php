<?php
// Connexion à la base de données
require_once 'bdconnect.php'; // Ce fichier doit contenir la connexion à MySQL via mysqli

// Vérifie la connexion
if (!$bdd) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

// Vérifie si un ID a été fourni
if (isset($_GET['id'])) {
    $id_demande = intval($_GET['id']); // Sécurisation avec intval()

    // Suppression de la demande
    $sql_delete = "DELETE FROM essai WHERE id = $id_demande";
    if (mysqli_query($bdd, $sql_delete)) {
        echo "Demande supprimée avec succès.";
    } else {
        echo "Erreur lors de la suppression de la demande : " . mysqli_error($bdd);
    }
} else {
    echo "ID de la demande non fourni.";
}

// Redirection vers la page des demandes
header("Location: gestionacceuil.php");
exit;
?>
