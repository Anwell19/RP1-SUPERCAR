<?php
include ("bdconnect.php");

// Échapper les caractères spéciaux pour éviter les erreurs SQL (et les injections SQL !)
$marque      = mysqli_real_escape_string($bdd, $_POST["marque"]);
$modele      = mysqli_real_escape_string($bdd, $_POST["modele"]);
$prix        = mysqli_real_escape_string($bdd, $_POST["prix"]);
$description = mysqli_real_escape_string($bdd, $_POST["description"]);
$image       = mysqli_real_escape_string($bdd, $_POST["image"]);

$ajout = "INSERT INTO voiture (marque, modèle, prix, description, image) 
          VALUES ('$marque', '$modele', '$prix', '$description', '$image')";

if (mysqli_query($bdd, $ajout)) {
    echo "<h2 align='center'>✅ Merci. Vos données sont bien insérées !</h2>";
} else {
    echo "<h2 align='center'>❌ Erreur SQL : " . mysqli_error($bdd) . "</h2>";
}

mysqli_close($bdd);
?>

<center><a href='voiture.php'>Retour</a></center>

