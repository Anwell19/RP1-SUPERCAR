<?php
//définir vos paramètres dec connexion

// nom du serveur 
$host="mysql-anwellmcci.alwaysdata.net";
// nom utilisateur
$login="434572";
// mot de passe
$pass = "espace2311!";
// nom de la base de données
$dbname="anwellmcci_supercar";



// créer la connexion avec la base de données
$bdd = mysqli_connect($host, $login, $pass, $dbname);


// vérification de la connexion avec la BD
if (!$bdd)
	{
		echo "Connexion non-reussie à MySQL: " . mysqli_connect_error();
	} 
else 
	{
		echo " ";
	}