<?php
include("bdconnect.php");

// Récupération des voitures
$sql = "SELECT * FROM voiture ORDER BY id_voiture DESC";
$result = mysqli_query($bdd, $sql);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Gestion des Voitures</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a0a;
            color: #fff;
            overflow-x: hidden;
        }

        /* Container principal */
        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #1a1a1a 0%, #0a0a0a 100%);
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 30px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-logo {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 30px;
            color: #aaa;
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
            font-weight: 600;
        }

        .menu-item::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(135deg, #e60000, #ff4444);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .menu-item:hover,
        .menu-item.active {
            color: #fff;
            background: rgba(230, 0, 0, 0.1);
        }

        .menu-item:hover::before,
        .menu-item.active::before {
            opacity: 1;
        }

        .logout-btn {
            margin: 20px 30px;
            padding: 15px;
            background: rgba(230, 0, 0, 0.1);
            border: 2px solid rgba(230, 0, 0, 0.3);
            border-radius: 12px;
            color: #e60000;
            text-align: center;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-weight: 700;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: rgba(230, 0, 0, 0.2);
            transform: translateY(-2px);
        }

        /* Main content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 40px;
        }

        /* Header */
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .content-header h1 {
            font-size: 42px;
            font-weight: 900;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .add-btn {
            padding: 15px 30px;
            background: linear-gradient(135deg, #e60000, #ff4444);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
        }

        .add-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(230, 0, 0, 0.5);
        }

        /* Table moderne */
        .table-container {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: rgba(230, 0, 0, 0.1);
        }

        th {
            padding: 20px;
            text-align: left;
            font-weight: 700;
            color: #e60000;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 1px;
        }

        tbody tr {
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: all 0.3s;
        }

        tbody tr:hover {
            background: rgba(230, 0, 0, 0.05);
        }

        td {
            padding: 20px;
            color: #ccc;
        }

        .car-image {
            width: 80px;
            height: 60px;
            object-fit: cover;
            border-radius: 10px;
            border: 2px solid rgba(255, 255, 255, 0.1);
        }

        .price {
            font-weight: 700;
            color: #e60000;
            font-size: 18px;
        }

        /* Boutons d'action */
        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 14px;
        }

        .btn-edit {
            background: rgba(255, 193, 7, 0.2);
            color: #ffc107;
            border: 1px solid rgba(255, 193, 7, 0.3);
        }

        .btn-edit:hover {
            background: #ffc107;
            color: #000;
        }

        .btn-delete {
            background: rgba(244, 67, 54, 0.2);
            color: #f44336;
            border: 1px solid rgba(244, 67, 54, 0.3);
        }

        .btn-delete:hover {
            background: #f44336;
            color: #fff;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 2000;
            align-items: center;
            justify-content: center;
            overflow-y: auto;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: linear-gradient(135deg, #1a1a1a, #2a2a2a);
            border: 2px solid rgba(230, 0, 0, 0.3);
            border-radius: 20px;
            padding: 40px;
            width: 90%;
            max-width: 600px;
            margin: 20px;
            animation: slideIn 0.5s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .modal-header h2 {
            font-size: 28px;
            color: #fff;
        }

        .close-modal {
            background: none;
            border: none;
            color: #fff;
            font-size: 30px;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close-modal:hover {
            color: #e60000;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #aaa;
            font-size: 14px;
            text-transform: uppercase;
        }

        .form-control {
            width: 100%;
            padding: 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s;
            outline: none;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.08);
            border-color: #e60000;
            box-shadow: 0 0 20px rgba(230, 0, 0, 0.2);
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }

        .submit-btn {
            width: 100%;
            padding: 18px;
            background: linear-gradient(135deg, #e60000, #ff4444);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
        }

        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(230, 0, 0, 0.5);
        }

        /* Responsive */
        @media (max-width: 968px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .main-content {
                margin-left: 0;
            }

            .content-header {
                flex-direction: column;
                align-items: flex-start;
            }

            table {
                font-size: 14px;
            }

            th, td {
                padding: 15px 10px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-logo">SuperCars</h2>
            </div>
            
            <div class="sidebar-menu">
                <a href="dashboard.html" class="menu-item">
                    <span>📊</span>
                    <span>Tableau de bord</span>
                </a>
                <a href="voiture.php" class="menu-item active">
                    <span>🚗</span>
                    <span>Gestion des voitures</span>
                </a>
                <a href="service.php" class="menu-item">
                    <span>🛠</span>
                    <span>Gestion des services</span>
                </a>
                <a href="essais.php" class="menu-item">
                    <span>📋</span>
                    <span>Demandes d'essai</span>
                </a>
                <a href="contact.php" class="menu-item">
                    <span>📩</span>
                    <span>Messages</span>
                </a>
            </div>

            <a href="deconnexion.php" class="logout-btn">
                <span>🔓</span>
                <span>Déconnexion</span>
            </a>
        </nav>
        
        <!-- Main content -->
        <main class="main-content">
            <div class="content-header">
                <h1>Gestion des Voitures</h1>
                <button class="add-btn" onclick="openModal()">
                    <span>+</span>
                    <span>Ajouter une voiture</span>
                </button>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Marque</th>
                            <th>Modèle</th>
                            <th>Prix</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= $row['id_voiture'] ?></td>
                            <td>
                                <img src="<?= htmlspecialchars($row['image']) ?>" 
                                     alt="<?= htmlspecialchars($row['modèle']) ?>" 
                                     class="car-image">
                            </td>
                            <td><?= htmlspecialchars($row['marque']) ?></td>
                            <td><?= htmlspecialchars($row['modèle']) ?></td>
                            <td class="price"><?= number_format($row['prix'], 0, '', ' ') ?> €</td>
                            <td><?= htmlspecialchars(substr($row['description'] ?? '', 0, 50)) ?>...</td>
                            <td>
                                <div class="action-buttons">
                                    <a href="voituremodif.php?id=<?= $row['id_voiture'] ?>" class="btn btn-edit">
                                        Modifier
                                    </a>
                                    <a href="voituresupp.php?id=<?= $row['id_voiture'] ?>" 
                                       class="btn btn-delete" 
                                       onclick="return confirm('Voulez-vous vraiment supprimer cette voiture ?');">
                                        Supprimer
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <!-- Modal Ajout Voiture -->
    <div class="modal" id="addCarModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Ajouter une Voiture</h2>
                <button class="close-modal" onclick="closeModal()">×</button>
            </div>
            <form method="POST" action="ajouter_voiture.php">
                <div class="form-group">
                    <label>Marque</label>
                    <input type="text" name="marque" class="form-control" placeholder="Ex: BMW" required>
                </div>
                <div class="form-group">
                    <label>Modèle</label>
                    <input type="text" name="modele" class="form-control" placeholder="Ex: M3 Competition" required>
                </div>
                <div class="form-group">
                    <label>Prix (€)</label>
                    <input type="number" name="prix" class="form-control" placeholder="89900" required>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" placeholder="Description détaillée..." required></textarea>
                </div>
                <div class="form-group">
                    <label>URL de l'image</label>
                    <input type="text" name="image" class="form-control" placeholder="https://..." required>
                </div>
                <button type="submit" class="submit-btn">Ajouter la voiture</button>
            </form>
        </div>
    </div>

    <script>
        function openModal() {
            document.getElementById('addCarModal').classList.add('active');
        }

        function closeModal() {
            document.getElementById('addCarModal').classList.remove('active');
        }

        // Fermer le modal en cliquant à l'extérieur
        document.getElementById('addCarModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });

        // Fermer avec la touche Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
    </script>
</body>
</html>
<?php mysqli_close($bdd); ?>