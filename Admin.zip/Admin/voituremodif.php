<?php
// Connexion à la base de données
include 'bdconnect.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $marque = $_POST['marque'];
        $modele = $_POST['modele'];
        $prix = $_POST['prix'];
        $description = $_POST['description'];
        $image = $_POST['image'];

        $stmt = $bdd->prepare("UPDATE voiture SET marque = ?, modèle = ?, prix = ?, description = ?, image = ? WHERE id_voiture = ?");
        $stmt->bind_param("sssssi", $marque, $modele, $prix, $description, $image, $id);

        if ($stmt->execute()) {
            header("Location: voiture.php");
            exit();
        } else {
            echo "Erreur lors de la mise à jour : " . $stmt->error;
        }
    }

    // Charger les infos actuelles
    $stmt = $bdd->prepare("SELECT * FROM voiture WHERE id_voiture = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $voiture = $result->fetch_assoc();

    if (!$voiture) die("Voiture introuvable.");
}
mysqli_close($bdd);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une voiture - SuperCars Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a0a;
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
        }

        /* Effet de fond */
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 30%, rgba(230, 0, 0, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(230, 0, 0, 0.05) 0%, transparent 50%);
            pointer-events: none;
        }

        /* Container principal */
        .form-container {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 700px;
            position: relative;
            z-index: 1;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            animation: slideIn 0.8s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Barre supérieure */
        .form-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #e60000, #ff4444, #e60000);
            background-size: 200% 100%;
            animation: shimmer 3s linear infinite;
            border-radius: 20px 20px 0 0;
        }

        @keyframes shimmer {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }

        /* Header */
        .form-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .form-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #e60000, #ff4444);
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            margin: 0 auto 20px;
            animation: float 3s ease-in-out infinite;
            box-shadow: 0 10px 30px rgba(230, 0, 0, 0.4);
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        .form-header h2 {
            font-size: 32px;
            font-weight: 900;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .form-header p {
            color: #666;
            font-size: 15px;
        }

        /* Preview de l'image */
        .image-preview {
            width: 100%;
            height: 200px;
            background: #1a1a1a;
            border-radius: 15px;
            margin-bottom: 30px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid rgba(255, 255, 255, 0.1);
        }

        .image-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .image-preview.empty {
            font-size: 48px;
            color: #333;
        }

        /* Formulaire */
        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #aaa;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .form-control {
            width: 100%;
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s;
            outline: none;
            font-family: inherit;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.08);
            border-color: #e60000;
            box-shadow: 0 0 20px rgba(230, 0, 0, 0.2);
        }

        .form-control::placeholder {
            color: #555;
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }

        /* Boutons */
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 18px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg, #e60000, #ff4444);
            color: #fff;
            position: relative;
            overflow: hidden;
        }

        .btn-primary::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            transform: translate(-50%, -50%);
            transition: width 0.5s, height 0.5s;
        }

        .btn-primary:hover::before {
            width: 300px;
            height: 300px;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(230, 0, 0, 0.5);
        }

        .btn-primary span {
            position: relative;
            z-index: 1;
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            border: 2px solid rgba(255, 255, 255, 0.1);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.2);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .form-container {
                padding: 30px 20px;
            }

            .form-header h2 {
                font-size: 28px;
            }

            .form-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="form-container">
        <div class="form-header">
            <div class="form-icon">🚗</div>
            <h2>Modifier la voiture</h2>
            <p>Mettez à jour les informations du véhicule</p>
        </div>

        <!-- Preview de l'image -->
        <div class="image-preview" id="imagePreview">
            <?php if (!empty($voiture['image'])): ?>
                <img src="<?= htmlspecialchars($voiture['image']) ?>" alt="Aperçu">
            <?php else: ?>
                <span class="empty">🖼️</span>
            <?php endif; ?>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Marque</label>
                <input type="text" 
                       name="marque" 
                       class="form-control" 
                       value="<?= htmlspecialchars($voiture['marque']) ?>" 
                       placeholder="Ex: BMW"
                       required>
            </div>

            <div class="form-group">
                <label>Modèle</label>
                <input type="text" 
                       name="modele" 
                       class="form-control" 
                       value="<?= htmlspecialchars($voiture['modèle']) ?>" 
                       placeholder="Ex: M3 Competition"
                       required>
            </div>

            <div class="form-group">
                <label>Prix (€)</label>
                <input type="text" 
                       name="prix" 
                       class="form-control" 
                       value="<?= htmlspecialchars($voiture['prix']) ?>" 
                       placeholder="89900"
                       required>
            </div>

            <div class="form-group">
                <label>Description</label>
                <textarea name="description" 
                          class="form-control" 
                          placeholder="Description détaillée du véhicule..."
                          required><?= htmlspecialchars($voiture['description']) ?></textarea>
            </div>

            <div class="form-group">
                <label>URL de l'image</label>
                <input type="text" 
                       name="image" 
                       id="imageUrl"
                       class="form-control" 
                       value="<?= htmlspecialchars($voiture['image']) ?>" 
                       placeholder="https://..."
                       required>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <span>💾 Enregistrer</span>
                </button>
                <a href="voiture.php" class="btn btn-secondary">
                    ← Annuler
                </a>
            </div>
        </form>
    </div>

    <script>
        // Prévisualisation de l'image en temps réel
        const imageUrlInput = document.getElementById('imageUrl');
        const imagePreview = document.getElementById('imagePreview');

        imageUrlInput.addEventListener('input', function() {
            const url = this.value.trim();
            if (url) {
                imagePreview.innerHTML = `<img src="${url}" alt="Aperçu" onerror="this.parentElement.innerHTML='<span class=\\'empty\\'>❌</span>'">`;
            } else {
                imagePreview.innerHTML = '<span class="empty">🖼️</span>';
            }
        });

        // Animation au focus des inputs
        const inputs = document.querySelectorAll('.form-control');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'scale(1.02)';
                this.parentElement.style.transition = 'transform 0.3s';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'scale(1)';
            });
        });
    </script>
</body>
</html>