
<?php
// Connexion à la base de données

include 'bdconnect.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $marque = $_POST['marque'];
    $modele = $_POST['modele']; // nom sans accent
    $prix = $_POST['prix'];
    $description = $_POST['description'];
    $image = $_POST['image'];

    $stmt = $bdd->prepare("UPDATE voiture SET marque = ?, modèle = ?, prix = ?, description = ?, image = ? WHERE id_voiture = ?");
    $stmt->bind_param("sssssi", $marque, $modele, $prix, $description, $image, $id);

    if ($stmt->execute()) {
        header("Location: voiture.php");
        exit();
    } else {
        echo "Erreur lors de la mise à jour : " . $stmt->error;
    }
}

// Charger les infos actuelles
$stmt = $bdd->prepare("SELECT * FROM voiture WHERE id_voiture = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$voiture = $result->fetch_assoc();
if (!$voiture) die("Voiture introuvable.");
}

mysqli_close($conn);
?>

 
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier une voiture</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
<div class="container mt-5">
    <h2>Modifier la voiture</h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="marque" class="form-label">Marque</label>
            <input type="text" name="marque" class="form-control" value="<?= htmlspecialchars($voiture['marque']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="modele" class="form-label">Modèle</label>
            <input type="text" name="modele" class="form-control" value="<?= htmlspecialchars($voiture['modèle']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="prix" class="form-label">Prix</label>
            <input type="text" name="prix" class="form-control" value="<?= htmlspecialchars($voiture['prix']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="5" required><?= htmlspecialchars($voiture['description']) ?></textarea>
        </div>
        <div class="mb-3">
            <label for="image" class="form-label">Image</label>
            <input type="text" name="image" class="form-control" value="<?= htmlspecialchars($voiture['image']) ?>" required>
        </div>
        <button type="submit" class="btn btn-success">Enregistrer</button>
        <a href="voiture.php" class="btn btn-secondary">Annuler</a>
    </form>
</div>
</body>
</html>
