<?php
include 'bdconnect.php';

if (isset($_GET['id'])) { 
    $id = intval($_GET['id']);

    // Si l'utilisateur a cliqué sur "Confirmer"
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirmer'])) {
        $sql = "DELETE FROM voiture WHERE id_voiture = $id";
        if ($bdd->query($sql) === TRUE) {
            header("Location: voiture.php?message=Voiture supprimée avec succès");
            exit();
        } else {
            echo "Erreur lors de la suppression : ";
        }
    }

    // Si l'utilisateur a cliqué sur "Annuler"
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['annuler'])) {
        header("Location: voiture.php?message=Suppression annulée");
        exit();
    }

} else {
    echo "ID de la voiture non spécifié.";
    exit();
}
?>

<!-- HTML de confirmation -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Confirmer la suppression</title>
</head>
<body>
    <h2>Confirmer la suppression</h2>
    <p>Voulez-vous vraiment supprimer cette voiture (ID <?= htmlspecialchars($id) ?>) ?</p>
    <form method="post">
        <button type="submit" name="confirmer">Oui, supprimer</button>
        <button type="submit" name="annuler">Non, annuler</button>
    </form>
</body>
</html>

