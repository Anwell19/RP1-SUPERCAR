<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "root", "root", "supercar");
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

$id = $_GET['id'] ?? null;
if (!$id) die("ID manquant.");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $libelle = $_POST['libellé'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];

    // Récupère l'ancienne image si aucune nouvelle image n'est envoyée
    if (empty($image)) {
        $res = $conn->query("SELECT image FROM service WHERE id_service = $id");
        $old = $res->fetch_assoc();
        $image = $old['image'];
    } else {
        move_uploaded_file($image_tmp, "uploads/" . $image);
    }

    $stmt = $conn->prepare("UPDATE service SET libellé = ?, description = ?, image = ? WHERE id_service = ?");
    $stmt->bind_param("sssi", $libelle, $description, $image, $id);

    if ($stmt->execute()) {
        header("Location: service.php");
        exit();
    } else {
        echo "Erreur lors de la mise à jour.";
    }
}

// Charger les infos actuelles
$stmt = $conn->prepare("SELECT * FROM service WHERE id_service = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$service = $result->fetch_assoc();
if (!$service) die("Service introuvable.");
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier un Service</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
<div class="container mt-5">
    <h2>Modifier le Service</h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="libellé" class="form-label">Libellé</label>
            <input type="text" name="libellé" class="form-control" value="<?= htmlspecialchars($service['libellé']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="5" required><?= htmlspecialchars($service['description']) ?></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Image actuelle :</label><br>
            <?php if ($service['image']): ?>
                <img src="uploads/<?= htmlspecialchars($service['image']) ?>" style="max-width: 200px;" alt="Service">
            <?php else: ?>
                <em>Aucune image</em>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="image" class="form-label">Changer l'image (optionnel)</label>
            <input type="file" name="image" class="form-control" accept="image/*">
        </div>
        <button type="submit" class="btn btn-success">Enregistrer</button>
        <a href="service.php" class="btn btn-secondary">Annuler</a>
    </form>
</div>
</body>
</html>

