<?php
// Connexion à la base de données
$conn = new mysqli("mysql-anwellmcci.alwaysdata.net", "434572", "espace2311!", "anwellmcci_supercar");
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

$id = $_GET['id'] ?? null;
if (!$id) die("ID manquant.");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $libelle = $_POST['libellé'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];

    // Récupère l'ancienne image si aucune nouvelle image n'est envoyée
    if (empty($image)) {
        $res = $conn->query("SELECT image FROM service WHERE id_service = $id");
        $old = $res->fetch_assoc();
        $image = $old['image'];
    } else {
        move_uploaded_file($image_tmp, "uploads/" . $image);
    }

    $stmt = $conn->prepare("UPDATE service SET libellé = ?, description = ?, image = ? WHERE id_service = ?");
    $stmt->bind_param("sssi", $libelle, $description, $image, $id);

    if ($stmt->execute()) {
        header("Location: service.php");
        exit();
    } else {
        echo "Erreur lors de la mise à jour.";
    }
}

// Charger les infos actuelles
$stmt = $conn->prepare("SELECT * FROM service WHERE id_service = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$service = $result->fetch_assoc();
if (!$service) die("Service introuvable.");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un Service - SuperCars Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a0a;
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
        }

        /* Effet de fond */
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 30%, rgba(230, 0, 0, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(230, 0, 0, 0.05) 0%, transparent 50%);
            pointer-events: none;
        }

        /* Container principal */
        .form-container {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 700px;
            position: relative;
            z-index: 1;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            animation: slideIn 0.8s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Barre supérieure */
        .form-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #e60000, #ff4444, #e60000);
            background-size: 200% 100%;
            animation: shimmer 3s linear infinite;
            border-radius: 20px 20px 0 0;
        }

        @keyframes shimmer {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }

        /* Header */
        .form-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .form-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #e60000, #ff4444);
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            margin: 0 auto 20px;
            animation: float 3s ease-in-out infinite;
            box-shadow: 0 10px 30px rgba(230, 0, 0, 0.4);
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        .form-header h2 {
            font-size: 32px;
            font-weight: 900;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .form-header p {
            color: #666;
            font-size: 15px;
        }

        /* Preview de l'image */
        .image-preview-section {
            margin-bottom: 30px;
        }

        .preview-label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #aaa;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .image-preview {
            width: 100%;
            height: 250px;
            background: #1a1a1a;
            border-radius: 15px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid rgba(255, 255, 255, 0.1);
            position: relative;
        }

        .image-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .image-preview.empty {
            font-size: 48px;
            color: #333;
        }

        .image-overlay {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(230, 0, 0, 0.9);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
        }

        /* Formulaire */
        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #aaa;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .form-control {
            width: 100%;
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s;
            outline: none;
            font-family: inherit;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.08);
            border-color: #e60000;
            box-shadow: 0 0 20px rgba(230, 0, 0, 0.2);
        }

        .form-control::placeholder {
            color: #555;
        }

        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }

        /* File input custom */
        .file-input-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
        }

        .file-input-wrapper input[type="file"] {
            position: absolute;
            left: -9999px;
        }

        .file-input-label {
            display: block;
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.05);
            border: 2px dashed rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            color: #aaa;
        }

        .file-input-label:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: #e60000;
            color: #fff;
        }

        .file-input-label.has-file {
            background: rgba(230, 0, 0, 0.1);
            border-color: #e60000;
            color: #e60000;
        }

        /* Boutons */
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 18px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg, #e60000, #ff4444);
            color: #fff;
            position: relative;
            overflow: hidden;
        }

        .btn-primary::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            transform: translate(-50%, -50%);
            transition: width 0.5s, height 0.5s;
        }

        .btn-primary:hover::before {
            width: 300px;
            height: 300px;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(230, 0, 0, 0.5);
        }

        .btn-primary span {
            position: relative;
            z-index: 1;
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            border: 2px solid rgba(255, 255, 255, 0.1);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.2);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .form-container {
                padding: 30px 20px;
            }

            .form-header h2 {
                font-size: 28px;
            }

            .form-actions {
                flex-direction: column;
            }

            .image-preview {
                height: 200px;
            }
        }
    </style>
</head>
<body>
    <div class="form-container">
        <div class="form-header">
            <div class="form-icon">🛠</div>
            <h2>Modifier le Service</h2>
            <p>Mettez à jour les informations du service</p>
        </div>

        <!-- Preview de l'image actuelle -->
        <div class="image-preview-section">
            <span class="preview-label">Image actuelle</span>
            <div class="image-preview">
                <?php if ($service['image']): ?>
                    <img src="<?= htmlspecialchars($service['image']) ?>" alt="Service">
                    <div class="image-overlay">Image actuelle</div>
                <?php else: ?>
                    <span class="empty">🖼️</span>
                <?php endif; ?>
            </div>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Libellé du service</label>
                <input type="text" 
                       name="libellé" 
                       class="form-control" 
                       value="<?= htmlspecialchars($service['libellé']) ?>" 
                       placeholder="Ex: Entretien complet"
                       required>
            </div>

            <div class="form-group">
                <label>Description</label>
                <textarea name="description" 
                          class="form-control" 
                          placeholder="Description détaillée du service..."
                          required><?= htmlspecialchars($service['description']) ?></textarea>
            </div>

            <div class="form-group">
                <label>Changer l'image (optionnel)</label>
                <div class="file-input-wrapper">
                    <input type="file" 
                           name="image" 
                           id="imageFile" 
                           accept="image/*">
                    <label for="imageFile" class="file-input-label" id="fileLabel">
                        📁 Cliquez pour choisir une nouvelle image
                    </label>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <span>💾 Enregistrer</span>
                </button>
                <a href="service.php" class="btn btn-secondary">
                    ← Annuler
                </a>
            </div>
        </form>
    </div>

    <script>
        // Gestion du file input
        const fileInput = document.getElementById('imageFile');
        const fileLabel = document.getElementById('fileLabel');

        fileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const fileName = this.files[0].name;
                fileLabel.textContent = `✓ ${fileName}`;
                fileLabel.classList.add('has-file');
            } else {
                fileLabel.textContent = '📁 Cliquez pour choisir une nouvelle image';
                fileLabel.classList.remove('has-file');
            }
        });

        // Animation au focus des inputs
        const inputs = document.querySelectorAll('.form-control');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'scale(1.02)';
                this.parentElement.style.transition = 'transform 0.3s';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'scale(1)';
            });
        });
    </script>
</body>
</html>