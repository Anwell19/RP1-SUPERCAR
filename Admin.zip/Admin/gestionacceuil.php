<?php
// Connexion à la base de données
require_once 'bdconnect.php';

if (!$bdd) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

// Récupération des données de la table accueil
$sql = "SELECT * FROM accueil";
$result = mysqli_query($bdd, $sql);

$accueils = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $accueils[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Gestion Accueil</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #1e1e2e; color: white; }
        .sidebar { height: 100vh; background-color: #242424; padding: 15px; }
        .sidebar a { color: white; text-decoration: none; display: block; padding: 10px; }
        .sidebar a:hover { background-color: #444; }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-3 col-lg-2 d-md-block sidebar">
            <h2 class="text-center">Admin</h2>
            <a href="accueil.html">📊 Tableau de bord</a>
            <a href="gestionacceuil.php">➕ Gestion accueil</a>
            <a href="voiture.php">🚗 Gestion des voitures</a>
            <a href="services.html">🛠 Gestion des services</a>
            <a href="essais.php">📋 Demandes d’essai</a>
            <a href="messages.html">📩 Messages</a>
            <a href="#logout">🔒 Déconnexion</a>
        </nav>

        <!-- Main content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <h1 class="mt-4">Gestion de l'Accueil</h1>

            <table class="table table-dark table-striped mt-4">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>Libellé</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
               <tbody>
                    <?php foreach ($accueils as $accueil): ?>
                        <?php
                             $id = isset($accueil['idacceuil']) ? $accueil['idacceuil'] : 0;
                             $image = isset($accueil['image']) ? htmlspecialchars($accueil['image']) : 'default.jpg';
                             $libelle = isset($accueil['libellé']) ? htmlspecialchars($accueil['libellé']) : '';
                             $description = isset($accueil['Description']) ? htmlspecialchars($accueil['Description']) : '';
                         ?>
                        <tr>
                              <td><?= $id ?></td>
                             <td><img src="../images/<?= $image ?>" width="100" alt="image"></td>
                             <td><?= $libelle ?></td>
                             <td><?= $description ?></td>
                         <td>
                             <a href="modifieraccueil.php?id=<?= $id ?>" class="btn btn-warning btn-sm">Modifier</a>
                             <a href="supprimeraccueil.php?id=<?= $id ?>" class="btn btn-danger btn-sm" onclick="return confirm('Confirmer la suppression ?')">Supprimer</a>
                         </td>
                      </tr>
                   <?php endforeach; ?>
                </tbody>
            </table>
        </main>
    </div>
</div>

<script src="admin.js"></script>
</body>
</html>
