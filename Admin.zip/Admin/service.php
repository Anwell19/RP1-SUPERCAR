<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "root", "root", "supercar");

if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupération des services
$sql = "SELECT id_service, libellé, description, image FROM service ORDER BY id_service ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Admin - Gestion des Services</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #1e1e2e; color: white; }
        .sidebar { height: 100vh; background-color: #242424; padding: 15px; }
        .sidebar a { color: white; text-decoration: none; display: block; padding: 10px; }
        .sidebar a:hover { background-color: #444; }
        img { max-width: 100px; border-radius: 5px; }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-3 col-lg-2 d-md-block sidebar">
            <h2 class="text-center">Admin</h2>
            <a href="accueil.html">📊 Tableau de bord</a>
            <a href="voiture.php">🚗 Gestion des voitures</a>
            <a href="service.php">🛠 Gestion des services</a>
            <a href="essais.html">📋 Demandes d’essai</a>
            <a href="messages.html">📩 Messages</a>
            <a href="#logout">🔒 Déconnexion</a>
        </nav>

        <!-- Main content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <h1 class="mt-4">Gestion des Services</h1>

            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addServiceModal">+ Ajouter un Service</button>

            <table class="table table-dark table-striped align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Libellé</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['id_service'] ?></td>
                        <td><?= htmlspecialchars($row['libellé']) ?></td>
                        <td><?= htmlspecialchars($row['description']) ?></td>
                        <td>
                            <?php if (!empty($row['image'])): ?>
                                <img src="uploads/<?= htmlspecialchars($row['image']) ?>" alt="Service">
                            <?php else: ?>
                                <em>Aucune image</em>
                            <?php endif; ?>
                        </td>
                        <td>
                        <div class="d-flex">
                            <a href="modifier_service.php?id=<?= $row['id_service'] ?>" class="btn btn-warning btn-sm me-2">Modifier</a>
                            <a href="supprimer_service.php?id=<?= $row['id_service'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Voulez-vous vraiment supprimer ce service ?');">Supprimer</a>
                        </div>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </main>
    </div>
</div>

<!-- Modal Ajout Service -->
<div class="modal fade" id="addServiceModal" tabindex="-1" aria-labelledby="addServiceLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form class="modal-content" action="ajouter_service.php" method="POST" enctype="multipart/form-data">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter un Service</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="text" class="form-control mb-2" name="libellé" placeholder="Nom du service" required>
                <textarea class="form-control mb-2" name="description" placeholder="Description" required></textarea>
                <input type="file" class="form-control mb-2" name="image" accept="image/*">
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success">Ajouter</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>
