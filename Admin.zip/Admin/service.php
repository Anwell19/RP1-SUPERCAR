<?php
// Connexion à la base de données
$conn = new mysqli("mysql-anwellmcci.alwaysdata.net", "434572", "espace2311!", "anwellmcci_supercar");

if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupération des services
$sql = "SELECT id_service, libellé, description, image FROM service ORDER BY id_service ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Gestion des Services</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a0a;
            color: #fff;
            overflow-x: hidden;
        }

        /* Container principal */
        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #1a1a1a 0%, #0a0a0a 100%);
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            padding: 30px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 0 30px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-logo {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 30px;
            color: #aaa;
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
            font-weight: 600;
        }

        .menu-item::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(135deg, #e60000, #ff4444);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .menu-item:hover,
        .menu-item.active {
            color: #fff;
            background: rgba(230, 0, 0, 0.1);
        }

        .menu-item:hover::before,
        .menu-item.active::before {
            opacity: 1;
        }

        .logout-btn {
            margin: 20px 30px;
            padding: 15px;
            background: rgba(230, 0, 0, 0.1);
            border: 2px solid rgba(230, 0, 0, 0.3);
            border-radius: 12px;
            color: #e60000;
            text-align: center;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-weight: 700;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: rgba(230, 0, 0, 0.2);
            transform: translateY(-2px);
        }

        /* Main content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 40px;
        }

        /* Header */
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .content-header h1 {
            font-size: 42px;
            font-weight: 900;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .add-btn {
            padding: 15px 30px;
            background: linear-gradient(135deg, #e60000, #ff4444);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
        }

        .add-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(230, 0, 0, 0.5);
        }

        /* Grille des services */
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 30px;
        }

        /* Carte de service */
        .service-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.4s ease;
            position: relative;
        }

        .service-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            transition: left 0.6s;
        }

        .service-card:hover::before {
            left: 100%;
        }

        .service-card:hover {
            transform: translateY(-10px);
            border-color: rgba(230, 0, 0, 0.5);
            box-shadow: 0 20px 60px rgba(230, 0, 0, 0.3);
        }

        .service-image {
            height: 200px;
            overflow: hidden;
            position: relative;
            background: #1a1a1a;
        }

        .service-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.6s ease;
        }

        .service-card:hover .service-image img {
            transform: scale(1.1);
        }

        .service-image::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 50%;
            background: linear-gradient(to top, rgba(10, 10, 10, 0.9), transparent);
        }

        .no-image {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            color: #333;
        }

        .service-content {
            padding: 25px;
        }

        .service-title {
            font-size: 22px;
            font-weight: 800;
            margin-bottom: 15px;
            color: #fff;
        }

        .service-description {
            color: #aaa;
            line-height: 1.6;
            margin-bottom: 20px;
            font-size: 14px;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .service-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 10px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 14px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        .btn-edit {
            background: rgba(255, 193, 7, 0.2);
            color: #ffc107;
            border: 1px solid rgba(255, 193, 7, 0.3);
        }

        .btn-edit:hover {
            background: #ffc107;
            color: #000;
            transform: translateY(-2px);
        }

        .btn-delete {
            background: rgba(244, 67, 54, 0.2);
            color: #f44336;
            border: 1px solid rgba(244, 67, 54, 0.3);
        }

        .btn-delete:hover {
            background: #f44336;
            color: #fff;
            transform: translateY(-2px);
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 2000;
            align-items: center;
            justify-content: center;
            overflow-y: auto;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: linear-gradient(135deg, #1a1a1a, #2a2a2a);
            border: 2px solid rgba(230, 0, 0, 0.3);
            border-radius: 20px;
            padding: 40px;
            width: 90%;
            max-width: 600px;
            margin: 20px;
            animation: slideIn 0.5s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .modal-header h2 {
            font-size: 28px;
            color: #fff;
        }

        .close-modal {
            background: none;
            border: none;
            color: #fff;
            font-size: 30px;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close-modal:hover {
            color: #e60000;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #aaa;
            font-size: 14px;
            text-transform: uppercase;
        }

        .form-control {
            width: 100%;
            padding: 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s;
            outline: none;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.08);
            border-color: #e60000;
            box-shadow: 0 0 20px rgba(230, 0, 0, 0.2);
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
            font-family: inherit;
        }

        .submit-btn {
            width: 100%;
            padding: 18px;
            background: linear-gradient(135deg, #e60000, #ff4444);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
        }

        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(230, 0, 0, 0.5);
        }

        /* Responsive */
        @media (max-width: 968px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .main-content {
                margin-left: 0;
            }

            .services-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-logo">SuperCars</h2>
            </div>
            
            <div class="sidebar-menu">
                <a href="dashboard.html" class="menu-item">
                    <span>📊</span>
                    <span>Tableau de bord</span>
                </a>
                <a href="voiture.php" class="menu-item">
                    <span>🚗</span>
                    <span>Gestion des voitures</span>
                </a>
                <a href="service.php" class="menu-item active">
                    <span>🛠</span>
                    <span>Gestion des services</span>
                </a>
                <a href="essais.php" class="menu-item">
                    <span>📋</span>
                    <span>Demandes d'essai</span>
                </a>
                <a href="contact.php" class="menu-item">
                    <span>📩</span>
                    <span>Messages</span>
                </a>
            </div>

            <a href="deconnexion.php" class="logout-btn">
                <span>🔓</span>
                <span>Déconnexion</span>
            </a>
        </nav>
        
        <!-- Main content -->
        <main class="main-content">
            <div class="content-header">
                <h1>Gestion des Services</h1>
                <button class="add-btn" onclick="openModal()">
                    <span>+</span>
                    <span>Ajouter un service</span>
                </button>
            </div>

            <div class="services-grid">
                <?php while ($row = $result->fetch_assoc()): ?>
                <div class="service-card">
                    <div class="service-image">
                        <?php if (!empty($row['image'])): ?>
                            <img src="<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['libellé']) ?>">
                        <?php else: ?>
                            <div class="no-image">🛠</div>
                        <?php endif; ?>
                    </div>
                    <div class="service-content">
                        <h3 class="service-title"><?= htmlspecialchars($row['libellé']) ?></h3>
                        <p class="service-description"><?= htmlspecialchars($row['description']) ?></p>
                        <div class="service-actions">
                            <a href="modifier_service.php?id=<?= $row['id_service'] ?>" class="btn btn-edit">
                                Modifier
                            </a>
                            <a href="supprimer_service.php?id=<?= $row['id_service'] ?>" 
                               class="btn btn-delete" 
                               onclick="return confirm('Voulez-vous vraiment supprimer ce service ?');">
                                Supprimer
                            </a>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </main>
    </div>

    <!-- Modal Ajout Service -->
    <div class="modal" id="addServiceModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Ajouter un Service</h2>
                <button class="close-modal" onclick="closeModal()">×</button>
            </div>
            <form method="POST" action="ajouter_service.php" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Nom du service</label>
                    <input type="text" name="libellé" class="form-control" placeholder="Ex: Entretien complet" required>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" placeholder="Description détaillée du service..." required></textarea>
                </div>
                <div class="form-group">
                    <label>Image</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                </div>
                <button type="submit" class="submit-btn">Ajouter le service</button>
            </form>
        </div>
    </div>

    <script>
        function openModal() {
            document.getElementById('addServiceModal').classList.add('active');
        }

        function closeModal() {
            document.getElementById('addServiceModal').classList.remove('active');
        }

        // Fermer le modal en cliquant à l'extérieur
        document.getElementById('addServiceModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });

        // Fermer avec la touche Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>