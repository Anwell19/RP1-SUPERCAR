<?php
$conn = new mysqli("mysql-anwellmcci.alwaysdata.net", "434572", "espace2311!", "anwellmcci_supercar");
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "DELETE FROM service WHERE id_service = $id";
    $conn->query($sql);
}
$conn->close();
header("Location: service.php");
exit;
