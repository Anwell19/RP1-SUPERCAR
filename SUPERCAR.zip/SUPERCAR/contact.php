<?php
include("bdconnect.php");
 
$nom = mysqli_real_escape_string($bdd, $_POST["nom"]);
$email = mysqli_real_escape_string($bdd, $_POST["email"]);
$objet = mysqli_real_escape_string($bdd, $_POST["objet"]);
$message = mysqli_real_escape_string($bdd, $_POST["message"]);
 
$ajouter = "INSERT INTO contact (nom, email, objet, message)
            VALUES ('$nom', '$email', '$objet', '$message')";
 
mysqli_query($bdd, $ajouter);
mysqli_close($bdd);
?>
   
   