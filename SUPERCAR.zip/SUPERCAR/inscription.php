<!DOCTYPE HTML>
<html lang=fr>
	<head>
		<meta charset = "utf-8" />
	</head>
	<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url(backcontact.jpg);
        }
	</style>

<body>

<?php
	// mettre en ligne la connexion avec la base de données
	include ("bdconnect.php");
	
	// récupérer les contenus des variables formulaires
	$nom				=$_POST["nom"];
	$email         	= $_POST["email"];
	$password         = $_POST["password"];

// préparer votre requête pour insérer des données dans la table PERSONNE
$inserer = "insert into inscription (nom,email,password) VALUES ('$nom','$email','$password')";
	
// exécuter la requête avec la fonction PHP
mysqli_query($bdd, $inserer);
	
	
// fermeture de la connexion avec la base de données
mysqli_close($bdd);
?>
<p>
	<br> </br>
	<h2 align='center'> Merci. Vos données sont bien insérées !!!<a href="connect.html"> Veuillez vous connecter</a> </h2>
</p>
</body>