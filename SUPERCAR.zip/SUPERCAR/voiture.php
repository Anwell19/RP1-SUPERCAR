<?php
// Connexion à la base de données
$host = "mysql-anwellmcci.alwaysdata.net";
$user = "434572";
$password = "espace2311!";
$dbname = "anwellmcci_supercar";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Requête pour récupérer toutes les voitures
$sql = "SELECT * FROM voiture";
$result = $conn->query($sql);

// Organisation des voitures par marque
$voituresParMarque = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $voituresParMarque[$row['marque']][] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SuperCars - Notre Collection</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a0a;
            color: #fff;
            overflow-x: hidden;
        }

        /* Header */
        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 20px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 1000;
            background: rgba(10, 10, 10, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logo p {
            font-size: 28px;
            font-weight: 800;
            margin: 0;
        }

        .logo span {
            background: linear-gradient(135deg, #fff 0%, #e60000 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .menu {
            display: flex;
            gap: 30px;
            list-style: none;
        }

        .menu a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        .menu a:hover {
            color: #e60000;
        }

        .login-btn {
            padding: 12px 30px;
            background: linear-gradient(135deg, #e60000, #ff4444);
            border: none;
            border-radius: 50px;
            color: #fff;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(230, 0, 0, 0.4);
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(230, 0, 0, 0.6);
        }

        /* Section principale */
        .gallery-section {
            padding-top: 120px;
            min-height: 100vh;
            padding-bottom: 80px;
        }

        .section-header {
            text-align: center;
            margin-bottom: 60px;
            padding: 0 20px;
        }

        .section-header h1 {
            font-size: 56px;
            font-weight: 900;
            margin-bottom: 15px;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .section-header p {
            font-size: 20px;
            color: #aaa;
        }

        /* Filtres de marque */
        .brand-filters {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 60px;
            padding: 0 20px;
        }

        .brand-btn {
            padding: 15px 35px;
            font-size: 16px;
            font-weight: 700;
            border: 2px solid rgba(255, 255, 255, 0.1);
            background: rgba(255, 255, 255, 0.03);
            color: #fff;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        .brand-btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(230, 0, 0, 0.2);
            transform: translate(-50%, -50%);
            transition: width 0.4s, height 0.4s;
        }

        .brand-btn:hover::before {
            width: 300px;
            height: 300px;
        }

        .brand-btn:hover {
            border-color: #e60000;
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(230, 0, 0, 0.3);
        }

        .brand-btn.active {
            background: linear-gradient(135deg, #e60000, #ff4444);
            border-color: #e60000;
            box-shadow: 0 10px 30px rgba(230, 0, 0, 0.5);
        }

        .brand-btn span {
            position: relative;
            z-index: 1;
        }

        /* Grille de voitures */
        .cars-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 40px;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 40px;
            opacity: 1;
            transition: opacity 0.3s ease;
        }

        .cars-grid.hidden {
            display: none;
        }

        /* Carte de voiture */
        .car-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border-radius: 20px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.4s ease;
            position: relative;
            cursor: pointer;
        }

        .car-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            transition: left 0.6s;
        }

        .car-card:hover::before {
            left: 100%;
        }

        .car-card:hover {
            transform: translateY(-10px);
            border-color: rgba(230, 0, 0, 0.5);
            box-shadow: 0 20px 60px rgba(230, 0, 0, 0.3);
        }

        .car-image {
            position: relative;
            height: 250px;
            overflow: hidden;
            background: #1a1a1a;
        }

        .car-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.6s ease;
        }

        .car-card:hover .car-image img {
            transform: scale(1.1);
        }

        .car-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            padding: 8px 16px;
            background: rgba(230, 0, 0, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .car-info {
            padding: 25px;
        }

        .car-brand {
            font-size: 14px;
            color: #e60000;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 8px;
        }

        .car-model {
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 15px;
            color: #fff;
        }

        .car-description {
            font-size: 14px;
            color: #aaa;
            margin-bottom: 20px;
            line-height: 1.6;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .car-price {
            font-size: 28px;
            font-weight: 900;
            color: #fff;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .car-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background: linear-gradient(135deg, #e60000, #ff4444);
            color: #fff;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(230, 0, 0, 0.5);
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.2);
        }

        /* Footer */
        footer {
            background: #050505;
            padding: 40px 5%;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            margin-top: 80px;
        }

        .footer-bottom p {
            color: #666;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .menu {
                display: none;
            }

            .section-header h1 {
                font-size: 36px;
            }

            .cars-grid {
                grid-template-columns: 1fr;
                padding: 0 20px;
                gap: 30px;
            }

            .brand-filters {
                gap: 10px;
            }

            .brand-btn {
                padding: 12px 20px;
                font-size: 14px;
            }
        }

        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .car-card {
            animation: fadeIn 0.5s ease-out;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <p><span>Super</span>Cars</p>
        </div>
        <ul class="menu">
            <li><a href="index.html">Accueil</a></li>
            <li><a href="voiture.php">Voitures</a></li>
            <li><a href="service.php">Services</a></li>
            <li><a href="connect.html">Demande d'essai</a></li>
            <li><a href="contact.html">Contact</a></li>
        </ul>
       
    </header>

    <section class="gallery-section">
        <div class="section-header">
            <h1>Notre Collection</h1>
            <p>Découvrez nos véhicules d'exception</p>
        </div>

        <div class="brand-filters">
            <button class="brand-btn active" onclick="showGallery('all')">
                <span>Tous</span>
            </button>
            <?php foreach (array_keys($voituresParMarque) as $marque): ?>
                <button class="brand-btn" onclick="showGallery('<?php echo htmlspecialchars($marque); ?>')">
                    <span><?php echo htmlspecialchars($marque); ?></span>
                </button>
            <?php endforeach; ?>
        </div>

        <!-- Toutes les voitures -->
        <div id="all" class="cars-grid">
            <?php
            // Réinitialiser le pointeur du résultat
            $result->data_seek(0);
            while ($voiture = $result->fetch_assoc()):
            ?>
                <div class="car-card">
                    <div class="car-image">
                        <img src="<?php echo htmlspecialchars($voiture['image']); ?>" alt="<?php echo htmlspecialchars($voiture['modèle']); ?>">
                        <div class="car-badge"><?php echo htmlspecialchars($voiture['marque']); ?></div>
                    </div>
                    <div class="car-info">
                        <div class="car-brand"><?php echo htmlspecialchars($voiture['marque']); ?></div>
                        <h3 class="car-model"><?php echo htmlspecialchars($voiture['modèle']); ?></h3>
                        <?php if (!empty($voiture['description'])): ?>
                            <p class="car-description"><?php echo htmlspecialchars($voiture['description']); ?></p>
                        <?php endif; ?>
                        <div class="car-price"><?php echo number_format($voiture['prix'], 0, '', ' '); ?> €</div>
                        <div class="car-actions">
                            <a href="savoir.php?id=<?php echo $voiture['id_voiture']; ?>" class="btn btn-primary">En savoir plus</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <!-- Voitures par marque -->
        <?php foreach ($voituresParMarque as $marque => $voitures): ?>
            <div id="<?php echo htmlspecialchars($marque); ?>" class="cars-grid hidden">
                <?php foreach ($voitures as $voiture): ?>
                    <div class="car-card">
                        <div class="car-image">
                            <img src="<?php echo htmlspecialchars($voiture['image']); ?>" alt="<?php echo htmlspecialchars($voiture['modèle']); ?>">
                            <div class="car-badge"><?php echo htmlspecialchars($voiture['marque']); ?></div>
                        </div>
                        <div class="car-info">
                            <div class="car-brand"><?php echo htmlspecialchars($voiture['marque']); ?></div>
                            <h3 class="car-model"><?php echo htmlspecialchars($voiture['modèle']); ?></h3>
                            <?php if (!empty($voiture['description'])): ?>
                                <p class="car-description"><?php echo htmlspecialchars($voiture['description']); ?></p>
                            <?php endif; ?>
                            <div class="car-price"><?php echo number_format($voiture['prix'], 0, '', ' '); ?> €</div>
                            <div class="car-actions">
                                <a href="savoir.php?id=<?php echo $voiture['id_voiture']; ?>" class="btn btn-primary">En savoir plus</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </section>

    <footer>
        <div class="footer-bottom">
            <p>© 2025 SuperCars - Tous droits réservés</p>
        </div>
    </footer>

    <script>
        function showGallery(brand) {
            // Retirer la classe active de tous les boutons
            document.querySelectorAll('.brand-btn').forEach(btn => {
                btn.classList.remove('active');
            });

            // Ajouter la classe active au bouton cliqué
            event.target.closest('.brand-btn').classList.add('active');

            // Cacher toutes les galeries
            document.querySelectorAll('.cars-grid').forEach(gallery => {
                gallery.classList.add('hidden');
            });

            // Afficher la galerie sélectionnée
            const selectedGallery = document.getElementById(brand);
            if (selectedGallery) {
                selectedGallery.classList.remove('hidden');
            }
        }
    </script>
</body>
</html>
<?php
$conn->close();
?>