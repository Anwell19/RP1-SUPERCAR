function openForm(service) {
    document.getElementById("serviceForm").style.display = "block";
    document.getElementById("service").value = service;
}
 
function closeForm() {
    document.getElementById("serviceForm").style.display = "none";
}