<?php 
include("bdconnect.php");
$email      = $_REQUEST["email"];
$password      = $_REQUEST["password"];

$requete = "SELECT email, password
            FROM inscription
            WHERE email='$email' AND password='$password'";
$curseur = mysqli_query($bdd, $requete);

$row = mysqli_num_rows($curseur);

if ($row == 1) {
    header("Location: index2.html");
    exit();
}
else {
    echo " <br /><br />NOM UTILISATEUR ou/et MOT DE PASSE non-trouvé(s)<br /> ";
    echo "<a href=\"connect.html\">Retour à l'authentification</a>";
}

mysqli_query($bdd, $requete);
mysqli_close($bdd);
?>
