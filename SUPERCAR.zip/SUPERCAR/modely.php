<?php
// Connexion à la base de données (adapter les infos ci-dessous à ton serveur)
$host = "localhost";
$user = "root";
$password = "root";
$dbname = "supercar"; // Change avec le vrai nom de ta base

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Requête pour récupérer toutes les voitures
$sql = "SELECT * FROM voiture";
$result = $conn->query($sql);

// Organisation des voitures par marque
$voituresParMarque = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $voituresParMarque[$row['marque']][] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Galerie de Voitures</title>
    <link rel="stylesheet" href="stylemodely.css"> <!-- Tu peux mettre les styles à part ici -->
    <script>
        function showGallery(brand) {
            document.querySelectorAll('.gallery').forEach(gallery => {
                gallery.style.display = 'none';
            });
            document.getElementById(brand).style.display = 'grid';
        }
        document.addEventListener("DOMContentLoaded", function() {
            showGallery('BMW'); // Galerie BMW au départ
        });
    </script>
    <style>
        /* Copie ici tes styles CSS depuis ton HTML original */
    </style>
</head>
<body>
    <header>
        <div class="menu_toggle"><span></span><span></span><span></span></div>
        <div class="logo"><p><span>Super</span>Cars</p></div>
        <ul class="menu">
            <li><a href="index.html">Accueil</a></li>
            <li><a href="modely.php">Voitures</a></li>
            <li><a href="service.php">Services</a></li>
            <li><a href="connect.html">Demande d'essai</a></li>
            <li><a href="Contact.html">Contact</a></li>
        </ul>
    </header>

    <div class="brand-menu">
        <?php foreach (array_keys($voituresParMarque) as $marque): ?>
            <button onclick="showGallery('<?php echo $marque; ?>')" class="brand-button <?php echo strtolower($marque); ?>">
                <?php echo htmlspecialchars($marque); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <?php foreach ($voituresParMarque as $marque => $voitures): ?>
        <div id="<?php echo $marque; ?>" class="gallery">
            <?php foreach ($voitures as $voiture): ?>
                <div class="car">
                    <img src="<?php echo htmlspecialchars($voiture['image']); ?>" alt="<?php echo htmlspecialchars($voiture['modèle']); ?>">
                    <h3><?php echo htmlspecialchars($voiture['modèle']); ?></h3>
                    <p><?php echo number_format($voiture['prix']); ?>€</p>
                    <a href="savoir.php?id=<?php echo $voiture['id_voiture']; ?>"><button>En savoir plus</button></a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>

    <footer>
        <div class="footer-bottom">
            <p>© 2025 - TonSiteWeb.com</p>
        </div>
    </footer>
</body>
</html>
