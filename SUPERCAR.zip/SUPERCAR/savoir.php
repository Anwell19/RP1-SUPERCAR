<?php
// Connexion à la base de données
$host = "mysql-anwellmcci.alwaysdata.net";
$user = "434572";
$password = "espace2311!";
$dbname = "anwellmcci_supercar";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Vérifie si l'id_voiture est passé en paramètre
if (isset($_GET['id'])) {
    $id_voiture = intval($_GET['id']);

    // Requête pour récupérer les informations de la voiture
    $stmt = $conn->prepare("SELECT * FROM voiture WHERE id_voiture = ?");
    $stmt->bind_param("i", $id_voiture);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $voiture = $result->fetch_assoc();
    } else {
        echo "Voiture non trouvée.";
        exit();
    }
} else {
    echo "ID de voiture non spécifié.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($voiture['modèle']); ?> - SuperCars</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a0a;
            color: #fff;
            overflow-x: hidden;
        }

        /* Header */
        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 20px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 1000;
            background: rgba(10, 10, 10, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logo p {
            font-size: 28px;
            font-weight: 800;
            margin: 0;
        }

        .logo span {
            background: linear-gradient(135deg, #fff 0%, #e60000 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .menu {
            display: flex;
            gap: 30px;
            list-style: none;
        }

        .menu a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        .menu a:hover {
            color: #e60000;
        }

        .login-btn {
            padding: 12px 30px;
            background: linear-gradient(135deg, #e60000, #ff4444);
            border: none;
            border-radius: 50px;
            color: #fff;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(230, 0, 0, 0.4);
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(230, 0, 0, 0.6);
        }

        /* Hero section avec image de fond */
        .hero-section {
            height: 60vh;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            margin-top: 70px;
        }

        .hero-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('<?php echo htmlspecialchars($voiture['image']); ?>');
            background-size: cover;
            background-position: center;
            filter: brightness(0.4);
        }

        .hero-bg::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 50%;
            background: linear-gradient(to top, #0a0a0a, transparent);
        }

        .hero-content {
            position: relative;
            z-index: 1;
            text-align: center;
            max-width: 800px;
            padding: 0 20px;
        }

        .brand-badge {
            display: inline-block;
            padding: 10px 24px;
            background: rgba(230, 0, 0, 0.2);
            border: 2px solid #e60000;
            border-radius: 30px;
            font-size: 14px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 20px;
            color: #ff4444;
        }

        .hero-title {
            font-size: 64px;
            font-weight: 900;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: slideUp 1s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .hero-price {
            font-size: 42px;
            font-weight: 900;
            color: #e60000;
            animation: slideUp 1s ease-out 0.2s both;
        }

        /* Section détails */
        .detail-section {
            max-width: 1400px;
            margin: -100px auto 80px;
            padding: 0 40px;
            position: relative;
            z-index: 2;
        }

        .detail-container {
            display: grid;
            grid-template-columns: 1.2fr 1fr;
            gap: 60px;
            align-items: start;
        }

        /* Image principale */
        .main-image-container {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
            position: relative;
        }

        .main-image-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(230, 0, 0, 0.1), transparent);
            pointer-events: none;
        }

        .main-image {
            width: 100%;
            height: 500px;
            object-fit: cover;
            display: block;
        }

        /* Informations */
        .info-container {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
        }

        .info-header {
            margin-bottom: 30px;
            padding-bottom: 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .info-header h2 {
            font-size: 36px;
            font-weight: 800;
            margin-bottom: 15px;
            color: #fff;
        }

        .info-list {
            list-style: none;
            margin-bottom: 30px;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 20px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: all 0.3s;
        }

        .info-item:hover {
            padding-left: 10px;
            background: rgba(230, 0, 0, 0.05);
        }

        .info-label {
            font-weight: 600;
            color: #aaa;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .info-label::before {
            content: '•';
            color: #e60000;
            font-size: 20px;
        }

        .info-value {
            font-weight: 700;
            color: #fff;
        }

        /* Description */
        .description-section {
            background: rgba(230, 0, 0, 0.05);
            border: 1px solid rgba(230, 0, 0, 0.2);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
        }

        .description-section h3 {
            font-size: 20px;
            margin-bottom: 15px;
            color: #e60000;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .description-section h3::before {
            content: '📋';
            font-size: 24px;
        }

        .description-text {
            color: #ccc;
            line-height: 1.8;
            font-size: 15px;
        }

        /* Boutons d'action */
        .action-buttons {
            display: grid;
            gap: 15px;
        }

        .action-btn {
            padding: 18px;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #e60000, #ff4444);
            color: #fff;
            box-shadow: 0 10px 30px rgba(230, 0, 0, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(230, 0, 0, 0.5);
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            border: 2px solid rgba(255, 255, 255, 0.1);
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.2);
        }

        /* Modal de réservation */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 3000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: linear-gradient(135deg, #1a1a1a, #2a2a2a);
            border: 2px solid #e60000;
            border-radius: 20px;
            padding: 40px;
            max-width: 500px;
            width: 90%;
            animation: popIn 0.5s ease;
        }

        @keyframes popIn {
            0% {
                transform: scale(0.5);
                opacity: 0;
            }
            100% {
                transform: scale(1);
                opacity: 1;
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .modal-header h3 {
            font-size: 28px;
            color: #fff;
        }

        .close-modal {
            background: none;
            border: none;
            color: #fff;
            font-size: 30px;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close-modal:hover {
            color: #e60000;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #aaa;
            font-size: 14px;
        }

        .form-control {
            width: 100%;
            padding: 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s;
            outline: none;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.08);
            border-color: #e60000;
            box-shadow: 0 0 20px rgba(230, 0, 0, 0.2);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        /* Footer */
        footer {
            background: #050505;
            padding: 40px 5%;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        footer p {
            color: #666;
        }

        /* Responsive */
        @media (max-width: 968px) {
            .detail-container {
                grid-template-columns: 1fr;
            }

            .hero-title {
                font-size: 42px;
            }

            .hero-price {
                font-size: 32px;
            }
        }

        @media (max-width: 768px) {
            .menu {
                display: none;
            }

            .detail-section {
                padding: 0 20px;
                margin-top: 0;
            }

            .info-container {
                padding: 30px 20px;
            }

            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <p><span>Super</span>Cars</p>
        </div>
        <ul class="menu">
            <li><a href="index.html">Accueil</a></li>
            <li><a href="voiture.php">Voitures</a></li>
            <li><a href="service.php">Services</a></li>
            <li><a href="connect.html">Demande d'essai</a></li>
            <li><a href="contact.html">Contact</a></li>
        </ul>
       
    </header>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="hero-bg"></div>
        <div class="hero-content">
            <span class="brand-badge"><?php echo htmlspecialchars($voiture['marque']); ?></span>
            <h1 class="hero-title"><?php echo htmlspecialchars($voiture['modèle']); ?></h1>
            <div class="hero-price"><?php echo number_format($voiture['prix'], 0, '', ' '); ?> €</div>
        </div>
    </section>

    <!-- Section Détails -->
    <section class="detail-section">
        <div class="detail-container">
            <!-- Image principale -->
            <div class="main-image-container">
                <img src="<?php echo htmlspecialchars($voiture['image']); ?>" 
                     alt="<?php echo htmlspecialchars($voiture['modèle']); ?>" 
                     class="main-image">
            </div>

            <!-- Informations -->
            <div class="info-container">
                <div class="info-header">
                    <h2><?php echo htmlspecialchars($voiture['modèle']); ?></h2>
                </div>

                <ul class="info-list">
                    <li class="info-item">
                        <span class="info-label">Marque</span>
                        <span class="info-value"><?php echo htmlspecialchars($voiture['marque']); ?></span>
                    </li>
                    <li class="info-item">
                        <span class="info-label">Modèle</span>
                        <span class="info-value"><?php echo htmlspecialchars($voiture['modèle']); ?></span>
                    </li>
                    <li class="info-item">
                        <span class="info-label">Prix</span>
                        <span class="info-value"><?php echo number_format($voiture['prix'], 0, '', ' '); ?> €</span>
                    </li>
                </ul>

                <?php if (!empty($voiture['description'])): ?>
                <div class="description-section">
                    <h3>Description</h3>
                    <p class="description-text"><?php echo nl2br(htmlspecialchars($voiture['description'])); ?></p>
                </div>
                <?php endif; ?>

                <div class="action-buttons">
                    <a href="connect.html" class="action-btn btn-primary" >
                        🚗 Réserver un essai
                </a>
                    <a href="voiture.php" class="action-btn btn-secondary">
                        ← Retour à la collection
                    </a>
                </div>
            </div>
        </div>
    </section>

    
</body>
</html>
<?php
$conn->close();
?>