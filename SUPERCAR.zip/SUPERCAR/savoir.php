<?php
// Connexion à la base de données
$host = "localhost";
$user = "root";
$password = "root";
$dbname = "supercar"; // Change avec le vrai nom de ta base

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Vérifie si l'id_voiture est passé en paramètre
if (isset($_GET['id'])) {
    $id_voiture = intval($_GET['id']);

    // Requête pour récupérer les informations de la voiture
    $stmt = $conn->prepare("SELECT * FROM voiture WHERE id_voiture = ?");
    $stmt->bind_param("i", $id_voiture);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $voiture = $result->fetch_assoc();
    } else {
        echo "Voiture non trouvée.";
        exit();
    }
} else {
    echo "ID de voiture non spécifié.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($voiture['modèle']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url(<?php echo htmlspecialchars($voiture['image']); ?>);
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        header {
            display: flex;
            justify-content: space-around;
            align-items: center;
            padding: 15px 20px;
            background-color: #222;
            color: white;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }
        .logo p {
            font-size: 24px;
            font-weight: bold;
            margin: 0;
        }
        .logo span {
            color: #e60000;
        }
        .menu {
            list-style: none;
            display: flex;
            gap: 20px;
            margin: 0;
            padding: 0;
        }
        .menu li {
            display: inline;
        }
        .menu a {
            text-decoration: none;
            color: white;
            font-size: 16px;
            font-weight: bold;
            padding: 10px 15px;
            transition: 0.3s;
        }
        .menu a:hover {
            background-color: #e60000;
            border-radius: 5px;
        }
        .container {
            display: flex;
            background: #001f3f;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(255, 255, 255, 0.1);
            width: 80%;
            max-width: 1000px;
        }
        .image {
            flex: 1;
        }
        .image img {
            width: 100%;
            border-radius: 10px;
        }
        .details {
            flex: 1;
            padding-left: 20px;
        }
        .details h2 {
            color: #007BFF;
        }
        .details ul {
            list-style-type: none;
            padding: 0;
        }
        .details ul li {
            padding: 5px 0;
        }
        .btn {
            display: inline-block;
            padding: 10px 15px;
            background: #007BFF;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }
        .btn:hover {
            background: #0056b3;
        }
        .form-container {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0.8);
            background: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            z-index: 3;
            transition: transform 0.3s ease;
        }
        .form-container.show {
            transform: translate(-50%, -50%) scale(1);
        }
        input {
            width: 100%;
            padding: 8px;
            margin-top: 10px;
            border: none;
            border-radius: 5px;
        }
        .close {
            position: absolute;
            top: 10px;
            right: 15px;
            cursor: pointer;
            font-size: 18px;
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <header>
        <!-- Menu burger -->
        <div class="menu_toggle">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <div class="logo">
            <p><span>Super</span>Cars</p>
        </div>
        <ul class="menu">
            <li><a href="index2.html">Accueil</a></li>
            <li><a href="modely.php">Voitures</a></li>
            <li><a href="service.html">Services</a></li>
            <li><a href="demandeessai.html">Demande d'essai</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </header>
    <div class="container">
        <div class="image">
            <img src="<?php echo htmlspecialchars($voiture['image']); ?>" alt="<?php echo htmlspecialchars($voiture['modèle']); ?>">
        </div>
        <div class="details">
            <h2><?php echo htmlspecialchars($voiture['modèle']); ?></h2>
            <ul>
                <li><strong>Marque :</strong> <?php echo htmlspecialchars($voiture['marque']); ?></li>
                <li><strong>Prix :</strong> <?php echo number_format($voiture['prix']); ?>€</li>
                <li><strong>Description :</strong> <?php echo htmlspecialchars($voiture['description']); ?></li>
            </ul>
            <a class="btn" href="connect.html">Réserver un essai</a>
        
        </div>
</body>
</html>