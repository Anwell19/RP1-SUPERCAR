<?php
//définir vos paramètres dec connexion

$host = "mysql-anwellmcci.alwaysdata.net";
$login = "434572";
$password = "espace2311!";
$dbname = "anwellmcci_supercar"; 



// créer la connexion avec la base de données
$bdd = mysqli_connect($host, $login, $password, $dbname);


// vérification de la connexion avec la BD
if (!$bdd)
	{
		echo "Connexion non-reussie à MySQL: " . mysqli_connect_error();
	} 
else 
	{
		echo "Connexion reussie à MySQL";
	}
?>
