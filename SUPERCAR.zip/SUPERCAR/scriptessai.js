function openForm(model) {
    document.getElementById("testDriveForm").style.display = "block";
    document.getElementById("car").value = model;
}
 
function closeForm() {
    document.getElementById("testDriveForm").style.display = "none";
}