<?php
// Connexion à la base de données
$host = "mysql-anwellmcci.alwaysdata.net";
$username = "434572";
$password = "espace2311!";
$dbname = "anwellmcci_supercar";

$bdd = mysqli_connect($host, $username, $password, $dbname);
if (!$bdd) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

$sql = "SELECT * FROM service";
$curseur = mysqli_query($bdd, $sql);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SuperCars - Nos Services</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0a0a;
            color: #fff;
            overflow-x: hidden;
        }

        /* Header */
        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 20px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 1000;
            background: rgba(10, 10, 10, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logo p {
            font-size: 28px;
            font-weight: 800;
            margin: 0;
        }

        .logo span {
            background: linear-gradient(135deg, #fff 0%, #e60000 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .menu {
            display: flex;
            gap: 30px;
            list-style: none;
        }

        .menu a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        .menu a:hover {
            color: #e60000;
        }

        .login-btn {
            padding: 12px 30px;
            background: linear-gradient(135deg, #e60000, #ff4444);
            border: none;
            border-radius: 50px;
            color: #fff;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(230, 0, 0, 0.4);
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(230, 0, 0, 0.6);
        }

        

        /* Section Services */
        .services-section {
            padding-top: 120px;
            min-height: 100vh;
            padding-bottom: 80px;
            position: relative;
        }

        .services-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 50%, rgba(230, 0, 0, 0.05) 0%, transparent 50%),
                radial-gradient(circle at 80% 80%, rgba(230, 0, 0, 0.03) 0%, transparent 50%);
            pointer-events: none;
        }

        .section-header {
            text-align: center;
            margin-bottom: 70px;
            padding: 0 20px;
            position: relative;
            z-index: 1;
        }

        .section-header h1 {
            font-size: 56px;
            font-weight: 900;
            margin-bottom: 15px;
        }

        .section-header h1 span {
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .section-header h2 {
            font-size: 20px;
            color: #aaa;
            font-weight: 400;
        }

        /* Grid de services */
        .services-grid {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 40px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 40px;
            position: relative;
            z-index: 1;
        }

        /* Carte de service avec effet flip 3D */
        .service-card {
            height: 450px;
            perspective: 1000px;
            cursor: pointer;
        }

        .card-inner {
            position: relative;
            width: 100%;
            height: 100%;
            transition: transform 0.8s;
            transform-style: preserve-3d;
        }

        .service-card:hover .card-inner {
            transform: rotateY(180deg);
        }

        .card-front, .card-back {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            border-radius: 20px;
            overflow: hidden;
        }

        /* Face avant */
        .card-front {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            flex-direction: column;
        }

        .service-image {
            height: 200px;
            overflow: hidden;
            position: relative;
        }

        .service-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.6s ease;
        }

        .service-card:hover .service-image img {
            transform: scale(1.1);
        }

        .service-image::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 50%;
            background: linear-gradient(to top, rgba(10, 10, 10, 0.9), transparent);
        }

        .service-icon {
            position: absolute;
            bottom: -30px;
            left: 30px;
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #e60000, #ff4444);
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            z-index: 2;
            box-shadow: 0 10px 30px rgba(230, 0, 0, 0.4);
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        .service-content {
            padding: 50px 30px 30px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .service-title {
            font-size: 26px;
            font-weight: 800;
            margin-bottom: 15px;
            color: #fff;
        }

        .service-description {
            color: #aaa;
            line-height: 1.8;
            font-size: 15px;
            flex: 1;
        }

        .card-indicator {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #e60000;
            font-weight: 700;
            font-size: 14px;
            margin-top: 20px;
        }

        .card-indicator::after {
            content: '→';
            transition: transform 0.3s;
        }

        .service-card:hover .card-indicator::after {
            transform: translateX(5px);
        }

        /* Face arrière */
        .card-back {
            background: linear-gradient(135deg, #e60000, #ff4444);
            transform: rotateY(180deg);
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .card-back h3 {
            font-size: 28px;
            margin-bottom: 20px;
            font-weight: 800;
        }

        .card-back p {
            line-height: 1.8;
            margin-bottom: 30px;
        }

        .contact-btn {
            padding: 15px 30px;
            background: rgba(255, 255, 255, 0.2);
            border: 2px solid #fff;
            border-radius: 50px;
            color: #fff;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
            text-decoration: none;
            display: inline-block;
        }

        .contact-btn:hover {
            background: #fff;
            color: #e60000;
            transform: translateY(-2px);
        }

        /* Stats Section */
        .stats-section {
            max-width: 1200px;
            margin: 0 auto 60px;
            padding: 0 40px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }

        .stat-card {
            text-align: center;
            padding: 40px 20px;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.02));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            transition: all 0.4s;
        }

        .stat-card:hover {
            transform: translateY(-10px);
            border-color: rgba(230, 0, 0, 0.5);
            box-shadow: 0 20px 40px rgba(230, 0, 0, 0.2);
        }

        .stat-number {
            font-size: 48px;
            font-weight: 900;
            background: linear-gradient(135deg, #fff, #e60000);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }

        .stat-label {
            color: #aaa;
            font-size: 16px;
            font-weight: 600;
        }

        /* CTA Section */
        .cta-section {
            max-width: 1200px;
            margin: 80px auto 0;
            padding: 60px;
            background: linear-gradient(135deg, rgba(230, 0, 0, 0.1), rgba(230, 0, 0, 0.05));
            border: 1px solid rgba(230, 0, 0, 0.3);
            border-radius: 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .cta-section::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(230, 0, 0, 0.1) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }

        @keyframes rotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .cta-content {
            position: relative;
            z-index: 1;
        }

        .cta-section h2 {
            font-size: 42px;
            font-weight: 900;
            margin-bottom: 20px;
        }

        .cta-section p {
            font-size: 18px;
            color: #aaa;
            margin-bottom: 30px;
        }

        .cta-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .cta-btn {
            padding: 16px 40px;
            border-radius: 50px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 16px;
            text-decoration: none;
            display: inline-block;
        }

        .cta-primary {
            background: linear-gradient(135deg, #e60000, #ff4444);
            color: #fff;
            border: none;
        }

        .cta-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(230, 0, 0, 0.5);
        }

        .cta-secondary {
            background: transparent;
            color: #fff;
            border: 2px solid #fff;
        }

        .cta-secondary:hover {
            background: #fff;
            color: #0a0a0a;
        }

        /* Footer */
        footer {
            background: #050505;
            padding: 40px 5%;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            margin-top: 80px;
        }

        .footer-bottom p {
            color: #666;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .menu {
                display: none;
            }

            .section-header h1 {
                font-size: 36px;
            }

            .services-grid {
                grid-template-columns: 1fr;
                padding: 0 20px;
                gap: 30px;
            }

            .service-card {
                height: 400px;
            }

            .cta-section {
                padding: 40px 20px;
                margin: 60px 20px 0;
            }

            .cta-section h2 {
                font-size: 32px;
            }

            .stats-section {
                padding: 0 20px;
            }
        }

        /* Animations */
        .fade-in-up {
            animation: fadeInUp 0.8s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <p><span>Super</span>Cars</p>
        </div>
        <ul class="menu">
            <li><a href="index.html">Accueil</a></li>
            <li><a href="voiture.php">Voitures</a></li>
            <li><a href="service.php">Services</a></li>
            <li><a href="connect.html">Demande d'essai</a></li>
            <li><a href="contact.html">Contact</a></li>
        </ul>
       
    </header>

    <section class="services-section">
        <div class="section-header fade-in-up">
            <h1><span>NOS</span> SERVICES</h1>
            <h2>Découvrez les services que nous proposons</h2>
        </div>

        <!-- Stats Section -->
        <div class="stats-section fade-in-up">
            <div class="stat-card">
                <div class="stat-number">15+</div>
                <div class="stat-label">Années d'expérience</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">2500+</div>
                <div class="stat-label">Clients satisfaits</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">500+</div>
                <div class="stat-label">Véhicules vendus</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">98%</div>
                <div class="stat-label">Satisfaction client</div>
            </div>
        </div>

        <div class="services-grid">
            <?php
            $icons = ['🚗', '🔧', '💰', '🌍', '✨', '🛡️'];
            $index = 0;
            while ($row = mysqli_fetch_assoc($curseur)) {
                $delay = $index * 0.1;
                $icon = $icons[$index % count($icons)];
                ?>
                <div class="service-card fade-in-up" style="animation-delay: <?php echo $delay; ?>s">
                    <div class="card-inner">
                        <div class="card-front">
                            <div class="service-image">
                                <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['libellé']); ?>">
                                <div class="service-icon"><?php echo $icon; ?></div>
                            </div>
                            <div class="service-content">
                                <h3 class="service-title"><?php echo htmlspecialchars($row['libellé']); ?></h3>
                                <p class="service-description"><?php echo nl2br(htmlspecialchars(substr($row['description'], 0, 150))); ?>...</p>
                                <div class="card-indicator">Voir les détails</div>
                            </div>
                        </div>
                        <div class="card-back">
                            <h3><?php echo htmlspecialchars($row['libellé']); ?></h3>
                            <p><?php echo nl2br(htmlspecialchars($row['description'])); ?></p>
                            <a href="contact.html" class="contact-btn">Nous contacter</a>
                        </div>
                    </div>
                </div>
                <?php
                $index++;
            }
            ?>
        </div>

        <!-- CTA Section -->
        <div class="cta-section fade-in-up">
            <div class="cta-content">
                <h2>Prêt à vivre l'expérience SuperCars ?</h2>
                <p>Découvrez nos véhicules d'exception et profitez de nos services premium</p>
                <div class="cta-buttons">
                    <a href="voiture.php" class="cta-btn cta-primary">Voir nos véhicules</a>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="footer-bottom">
            <p>© 2025 SuperCars - Tous droits réservés</p>
        </div>
    </footer>
</body>
</html>
<?php
mysqli_free_result($curseur);
mysqli_close($bdd);
?>